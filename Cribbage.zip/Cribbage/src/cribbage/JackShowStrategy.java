package cribbage;

import ch.aplu.jcardgame.Card;
import ch.aplu.jcardgame.Hand;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class JackShowStrategy implements ShowStrategy{

    private final static int JACK_MARK = 1;
    private final static int JACK = 11;

    private ArrayList<Integer> scoreList;
    private ArrayList<Card[]> successCombinationList;

    public JackShowStrategy() {
        scoreList = new ArrayList<>();
        successCombinationList = new ArrayList<>();
    }

    @Override
    public CombinationResult calculateScore(Hand h) {
        int starterSuit = h.getLast().getSuitId();
        int handLength = h.getNumberOfCards();
        Card[] jackCard = new Card[1];
        for (int i = 0; i < handLength - 1; i++) {
            if (h.get(i).getSuitId() == starterSuit && ((Cribbage.Rank)h.get(i).getRank()).order == JACK) {
                jackCard[0] = h.get(i).clone();
                scoreList.add(JACK_MARK);
                successCombinationList.add(jackCard.clone());
            }
        }
        return new CombinationResult(scoreList, successCombinationList);
    }
}
