package cribbage;

import ch.aplu.jcardgame.Card;
import ch.aplu.jcardgame.Hand;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class TotalsShowStrategy implements ShowStrategy {

    public final static int FIFTEEN = 15;
    public final static int FIFTEEN_MARK = 2;

    private ArrayList<Integer> scoreList;
    private ArrayList<Card[]> successCombinationList;

    public TotalsShowStrategy() {
        scoreList = new ArrayList<>();
        successCombinationList = new ArrayList<>();
    }

    @Override
    public CombinationResult calculateScore(Hand h) {
        int handLength = h.getNumberOfCards();
        // Need as least two cards to reach 15 so no need to check if the hand has only one card
        if (handLength >= 2) {
            ArrayList<Card> cards = h.getCardList();
            ArrayList<Card[]> combinationArrayList = new ArrayList<>();
            for (int i = 1; i <= handLength; i++) {
                generateCombinations(cards, handLength, i, combinationArrayList);
            }
            for (Card[] combination : combinationArrayList) {
                if (getPoints(combination) == FIFTEEN) {
                    scoreList.add(FIFTEEN_MARK);
                    successCombinationList.add(combination.clone());
                }
            }
        }
        return new CombinationResult(scoreList, successCombinationList);
    }

    public int getPoints(Card[] cards) {
        int points = 0;
        for (int i = 0; i < cards.length; i++) {
            points += ((Cribbage.Rank)cards[i].getRank()).value;
        }
        return points;
    }

}