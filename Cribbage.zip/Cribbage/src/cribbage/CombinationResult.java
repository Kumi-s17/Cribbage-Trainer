package cribbage;

import ch.aplu.jcardgame.Card;
import java.util.ArrayList;

public class CombinationResult {

    private ArrayList<Integer> scoreList;
    private ArrayList<Card[]> successCombinationList;

    public CombinationResult(ArrayList<Integer> scoreList, ArrayList<Card[]> successCombinationList) {
        this.scoreList = scoreList;
        this.successCombinationList = successCombinationList;
    }

    public ArrayList<Integer> getScoreList() {
        return scoreList;
    }

    public ArrayList<Card[]> getSuccessCombinationList() {
        return successCombinationList;
    }
}
