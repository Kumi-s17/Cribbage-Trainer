package cribbage;

import ch.aplu.jcardgame.Card;
import ch.aplu.jcardgame.Hand;

import java.util.Map;

public class PairsPlayStrategy implements PlayStrategy {
    private final static int PAIR = 2;
    private final static int TRIP = 3;
    private final static int QUAD = 4;
    private final static int PAIR_MARK = 2;
    private final static int TRIP_MARK = 6;
    private final static int QUAD_MARK = 12;

    private final Map<Integer, Integer> pairMap = Map.of(
            PAIR,PAIR_MARK,
            TRIP,TRIP_MARK,
            QUAD,QUAD_MARK
    );


    @Override
    public int calculateScore(Hand h) {
        return playPair(h, PAIR) + playPair(h, TRIP) + playPair(h, QUAD);
    }

    public int playPair(Hand h, int pairNum) {
        int handLength = h.getNumberOfCards();
        if (handLength < pairNum) {
            return 0;
        } else {
            // System.out.println("card1 value" + ((Cribbage.Rank)newHand.get(0).getRank()).order);
            // System.out.println("card2 value" + ((Cribbage.Rank)newHand.get(1).getRank()).order);
            Card[] cards = new Card[pairNum];
            for (int i = 0; i < pairNum; i++) {
                cards[i] = h.get(handLength - i - 1);
            }
            for (int i = 0; i < pairNum - 1; i++) {
                if (((Cribbage.Rank)cards[i].getRank()).order != ((Cribbage.Rank)cards[i+1].getRank()).order) {
                    return 0;
                }
            }
            return pairMap.get(pairNum);
        }
    }

}