package cribbage;

import ch.aplu.jcardgame.Card;
import ch.aplu.jcardgame.Hand;

import java.util.ArrayList;

public interface ShowStrategy {

    CombinationResult calculateScore(Hand h);

    // Generate all possible combinations of given cards using recursion.

    /* @online
       author = {Devesh Agrawal},
       url = {https://www.geeksforgeeks.org/print-all-possible-combinations-of-r-elements-in-a-given-array-of-size-n/},
    }*/

    default void combinationUtil(ArrayList<Card> cards, Card[] data, int start,
                                 int end, int index, int r, ArrayList<Card[]> combinationList)
    {
        if (index == r)
        {
            combinationList.add(data.clone());
            return;
        }

        // replace index with all possible elements. The condition
        // "end-i+1 >= r-index" makes sure that including one element
        // at index will make a combination with remaining elements
        // at remaining positions
        for (int i=start; i<=end && end-i+1 >= r-index; i++)
        {
            data[index] = cards.get(i).clone();
            combinationUtil(cards, data, i+1, end, index+1, r, combinationList);
        }
    }

    // in cards of length n. This function mainly uses combinationUtil()
    default void generateCombinations(ArrayList<Card> cards, int n, int r, ArrayList<Card[]> combinationList) {
        // A temporary array to store all combination one by one
        Card[] data=new Card[r];
        // Print all combination using temporary array 'data[]'
        combinationUtil(cards, data, 0, n-1, 0, r, combinationList);
    }
}
