package cribbage;

import ch.aplu.jcardgame.Card;
import ch.aplu.jcardgame.Hand;

import java.io.File;  // Import the File class
import java.io.FileWriter;
import java.io.IOException;  // Import the IOException class to handle errors
import java.lang.reflect.InvocationTargetException;

public class Logger {

    public static final String FILE_NAME = "cribbage.log";
    public static final Boolean APPEND = true;

    public Logger() {
        createLog();
    }

    /**
     * Creates the Log File if it doesnt exist already
     */
    public void createLog() {
        try{
            File log = new File(FILE_NAME);
            if(log.createNewFile()){
                // System.out.println("File created: " + log.getName());
            }
            else {
                // System.out.println("File already exist");
            }
        }
        catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    /**
     * Write a message into the log file
     * @param message Message to write into the log
     */
    public void writeToLog(String message) {
        try {
            FileWriter myLogger = new FileWriter(FILE_NAME, APPEND);
            myLogger.write(message  + "\n");
            myLogger.close();
            System.out.println("Successfully wrote to the file.");

        } catch (IOException e) {
            System.out.println("An error occurred while writing to the log.");
            e.printStackTrace();
        }
    }

    /**
     * Logs the Seed value of the game
     * @param seed Seed value the game is running on
     */
    public void logSeedNumber(int seed) {
        try{
            FileWriter myLogger = new FileWriter(FILE_NAME, APPEND);
            myLogger.write("seed," + seed + "\n");
            myLogger.close();
            // System.out.println("Successfully wrote seed to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred while writing to the log.");
            e.printStackTrace();
        }
    }

    /**
     * Logs the Class of a player
     * @param player Player to be logged
     */
    public void logPlayerNumber(IPlayer player) {
        try {
            FileWriter myLogger = new FileWriter(FILE_NAME, APPEND);
            myLogger.write(player.getClass().getName() + ",P" +  player.id + "\n");
            myLogger.close();
            // System.out.println("Successfully wrote Class to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred while writing class to the log.");
            e.printStackTrace();
        }
    }

    /**
     * Logs the cards that are dealt at the start of the came
     * @param cribbage The Game
     * @param hand The set of cards that was dealt out
     */
    public void logInitialDeal(Cribbage cribbage, Hand hand, int playerNumber) {
        try {
            FileWriter myLogger = new FileWriter(FILE_NAME, APPEND);
            myLogger.write("deal,P" + playerNumber + "," + cribbage.canonical(hand) + "\n");
            myLogger.close();
        } catch (IOException e) {
            System.out.println("An error occurred while writing class to the log.");
            e.printStackTrace();
        }
    }

    /**
     * Logs the Cards that were discarded by the player
     * @param cribbage The Game
     * @param hand The set of cards that were discarded
     * @param playerNumber The Player Number
     */
    public void logDiscardCards(Cribbage cribbage, Hand hand, int playerNumber) {
        try {
            FileWriter myLogger = new FileWriter(FILE_NAME, APPEND);
            myLogger.write("discard,P" + playerNumber + "," + cribbage.canonical(hand) + "\n");
            myLogger.close();
        } catch (IOException e) {
            System.out.println("An error occurred while writing class to the log.");
            e.printStackTrace();
        }
    }

    /**
     * Logs the Starter Card
     * @param cribbage The Game
     * @param card The Starter Card
     */
    public void logStarterCard(Cribbage cribbage, Card card) {
        try {
            FileWriter myLogger = new FileWriter(FILE_NAME, APPEND);
            myLogger.write("starter," + cribbage.canonical(card) + "\n");
            myLogger.close();
        } catch (IOException e) {
            System.out.println("An error occurred while writing starter card to the log.");
            e.printStackTrace();
        }
    }

    /**
     * Logs the Card that was just played by a player
     * @param cribbage The Game
     * @param segmentTotal The current total of this current segment
     * @param card The Card that was just played
     * @param player The Player number of the player who played the card
     */
    public void logPlayCard(Cribbage cribbage, int segmentTotal ,Card card, IPlayer player) {
        try {
            FileWriter myLogger = new FileWriter(FILE_NAME, APPEND);
            myLogger.write("play,P" + player.id + "," + segmentTotal + "," + cribbage.canonical(card) + "\n");
            myLogger.close();
        } catch (IOException e) {
            System.out.println("An error occurred while writing play card to the log.");
            e.printStackTrace();
        }
    }

    /**
     * Logs the score that the player got during The Play phase
     * @param player The Player who achieved the score
     * @param currentScore The new score of the player
     * @param scoreAchieved The Score the player got
     * @param scoreType The type of score the player got
     */
    public void logPlayScore(IPlayer player, int currentScore, int scoreAchieved, String scoreType) {
        try {
            FileWriter myLogger = new FileWriter(FILE_NAME, APPEND);
            myLogger.write("score,P" + player.id + "," + currentScore + "," + scoreAchieved + "," +
                            scoreType + "\n");
            myLogger.close();
        } catch (IOException e) {
            System.out.println("An error occurred while writing Play Score to the log.");
            e.printStackTrace();
        }

    }

    /**
     * Logs the score that the player got during The Show phase
     * @param cribbage The Game
     * @param player The Player who achieved the score
     * @param currentScore The new score of the player
     * @param scoreAchieved The Score the player got
     * @param scoreType The type of score the player got
     * @param hand The Set of cards that achieved that score type
     */
    public void logShowScore(Cribbage cribbage, IPlayer player, int currentScore, int scoreAchieved, String scoreType,
                             Hand hand) {
        try {
            FileWriter myLogger = new FileWriter(FILE_NAME, APPEND);
            myLogger.write("score,P" + player.id + "," + currentScore + "," + scoreAchieved + "," + scoreType + ","
                            + cribbage.canonical(hand) + "\n");
            myLogger.close();
        } catch (IOException e) {
            System.out.println("An error occurred while writing Show Score to the log.");
            e.printStackTrace();
        }
    }

    /**
     * Logs the Hand of the Player during The Show
     * @param cribbage The Game
     * @param player The Player
     * @param starterCard The Starter Card of the round
     * @param hand The Hand the Player had
     */
    public void logShowHand(Cribbage cribbage, IPlayer player, Card starterCard, Hand hand) {
        try {
            FileWriter myLogger = new FileWriter(FILE_NAME, APPEND);
            myLogger.write("show,P" + player.id + "," + cribbage.canonical(starterCard) + "+" +
                            cribbage.canonical(hand) + "\n");
            myLogger.close();
        } catch (IOException e) {
            System.out.println("An error occurred while writing Show Hand to the log.");
            e.printStackTrace();
        }
    }

}

