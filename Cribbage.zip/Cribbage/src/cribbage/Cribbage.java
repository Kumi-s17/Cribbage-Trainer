package cribbage;

// Cribbage.java

import ch.aplu.jcardgame.*;
import ch.aplu.jgamegrid.*;

import java.awt.Color;
import java.awt.Font;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Cribbage extends CardGame {

	static Cribbage cribbage;  // Provide access to singleton
	// Logger
	Logger logger = new Logger();
	Score Score = new Score(nPlayers, logger, this);

	// Seed for randomisation.
	private static int SEED;
	static Random random;
	static boolean ANIMATE;
	private static final int GO = 1;
	private static final int FIFTEEN = 15;
	private static final int FIFTEEN_TWO = 2;
	private static final int THIRTYONE = 31;
	private static final int THIRTYONE_TWO = 2;

	private final String version = "0.1";
	// Default number of players
	static public final int nPlayers = 2;
	// Player array
	private static final IPlayer[] players = new IPlayer[nPlayers];
	// Score actors
	private final Actor[] scoreActors = {null, null}; //, null, null };
	// Number of Start Cards to deal out for each Player at the start of the game
	public final int nStartCards = 6;
	// Number of cards to discard to the crib for each Player
	public final int nDiscards = 2;
	final static Deck deck = new Deck(Suit.values(), Rank.values(), "cover", new MyCardValues());
	private final Hand[] hands = new Hand[nPlayers];
	private Hand starter;
	private Hand crib;
	// Displays the cards in a row with given maximal width.
	private final int handWidth = 400;
	private final int cribWidth = 150;
	private final int segmentWidth = 180;
	// Location of visible game objects
	private final Location seedLocation = new Location(5, 25);
	private final Location starterLocation = new Location(50, 625);
	private final Location cribLocation = new Location(700, 625);
	private final Location[] handLocations = {
			new Location(360, 75),
			new Location(360, 625)
	};
	private final Location[] scoreLocations = {
			new Location(590, 25),
			new Location(590, 675)
	};
	private final Location[] segmentLocations = {  // need at most three as 3x31=93 > 2x4x10=80
			new Location(150, 350),
			new Location(400, 350),
			new Location(650, 350)
	};
	private final Location textLocation = new Location(350, 450);
	// private final TargetArea cribTarget = new TargetArea(cribLocation, CardOrientation.NORTH, 1, true);

	// Font for score actors
	final Font bigFont = new Font("Serif", Font.BOLD, 36);
	// Font for seed actor
	final Font normalFont = new Font("Serif", Font.BOLD, 24);

	public static void setStatus(String string) {
		cribbage.setStatusText(string);
	}

	public enum Suit {
		CLUBS, DIAMONDS, HEARTS, SPADES
	}

	public enum Rank {
		// Order of cards is tied to card images
		ACE(1,1), KING(13,10), QUEEN(12,10), JACK(11,10), TEN(10,10), NINE(9,9), EIGHT(8,8), SEVEN(7,7), SIX(6,6), FIVE(5,5), FOUR(4,4), THREE(3,3), TWO(2,2);
		public final int order;
		public final int value;
		Rank(int order, int value) {
			this.order = order;
			this.value = value;
		}
	}

	static class MyCardValues implements Deck.CardValues { // Need to generate a unique value for every card
		public int[] values(Enum suit) {  // Returns the value for each card in the suit
			return Stream.of(Rank.values()).mapToInt(r -> (((Rank) r).order-1)*(Suit.values().length)+suit.ordinal()).toArray();
		}
	}

	class Segment {
		Hand segment;
		boolean go;
		int lastPlayer;
		boolean newSegment;

		void reset(final List<Hand> segments) {
			segment = new Hand(deck);
			segment.setView(Cribbage.this, new RowLayout(segmentLocations[segments.size()], segmentWidth));
			segment.draw();
			go = false;        // No-one has said "go" yet
			lastPlayer = -1;   // No-one has played a card yet in this segment
			newSegment = false;  // Not ready for new segment yet
		}
	}

	static int cardValue(Card c) {
		return ((Cribbage.Rank) c.getRank()).value;
	}

	/*
	Canonical String representations of Suit, Rank, Card, and Hand
	*/
	String canonical(Suit s) { return s.toString().substring(0, 1); }

	String canonical(Rank r) {
		switch (r) {
			case ACE:case KING:case QUEEN:case JACK:case TEN:
				return r.toString().substring(0, 1);
			default:
				return String.valueOf(r.value);
		}
	}

	String canonical(Card c) { return canonical((Rank) c.getRank()) + canonical((Suit) c.getSuit()); }

	String canonical(Hand h) {
		Hand h1 = new Hand(deck); // Clone to sort without changing the original hand
		for (Card C: h.getCardList()) h1.insert(C.getSuit(), C.getRank(), false);
		h1.sort(Hand.SortType.POINTPRIORITY, false);
		return "[" + h1.getCardList().stream().map(this::canonical).collect(Collectors.joining(",")) + "]";
	}

	int total(Hand hand) {
		int total = 0;
		for (Card c: hand.getCardList()) total += cardValue(c);
		return total;
	}

	public static <T extends Enum<?>> T randomEnum(Class<T> clazz){
		int x = random.nextInt(clazz.getEnumConstants().length);
		return clazz.getEnumConstants()[x];
	}

	// Transfer(move) a Card c to Hand h according to ANIMATE or NOT.
	void transfer(Card c, Hand h) {
		// If ANIMATE is true then transfer(move) Card c to Hand.
		if (ANIMATE) {
			c.transfer(h, true);
		} else {
			c.removeFromHand(true);
			h.insert(c, true);
		}
	}

	private void dealingOut(Hand pack, Hand[] hands) {
		for (int i = 0; i < nStartCards; i++) {
			for (int j=0; j < nPlayers; j++) {
				Card dealt = randomCard(pack);
				dealt.setVerso(false);  // Show the face
				transfer(dealt, hands[j]);
			}
		}
	}

	public static Card randomCard(Hand hand){
		int x = random.nextInt(hand.getNumberOfCards());
		return hand.get(x);
	}

	// Initialise the scores
	private void initScore() {
		// Initialise both the scores array and scores actors array
		for (int i = 0; i < nPlayers; i++) {
			Score.scores[i] = 0;
			// Constructs a unrotatable text actor that displays the given text
			// with given text color, background color, and text font.
			scoreActors[i] = new TextActor(String.valueOf(Score.scores[i]), Color.WHITE, bgColor, bigFont);
			addActor(scoreActors[i], scoreLocations[i]);
		}
	}

	private void updateScores() {
		for (int i = 0; i < nPlayers; i++) {
			removeActor(scoreActors[i]);
			scoreActors[i] = new TextActor(String.valueOf(Score.scores[i]), Color.WHITE, bgColor, bigFont);
			addActor(scoreActors[i], scoreLocations[i]);
		}
	}

	private void deal(Hand pack, Hand[] hands) {
		for (int i = 0; i < nPlayers; i++) {
			hands[i] = new Hand(deck);
			// players[i] = (1 == i ? new HumanPlayer() : new RandomPlayer());
			players[i].setId(i);
			players[i].startSegment(deck, hands[i]);
		}
		RowLayout[] layouts = new RowLayout[nPlayers];
		for (int i = 0; i < nPlayers; i++) {
			layouts[i] = new RowLayout(handLocations[i], handWidth);
			layouts[i].setRotationAngle(0);
			// layouts[i].setStepDelay(10);
			hands[i].setView(this, layouts[i]);
			hands[i].draw();
		}
		layouts[0].setStepDelay(0);

		dealingOut(pack, hands);
		for (int i = 0; i < nPlayers; i++) {
			hands[i].sort(Hand.SortType.POINTPRIORITY, true);
		}
		layouts[0].setStepDelay(0);

		//Logging PLayers
		for (int i = 0; i < nPlayers; i++){
			logger.logPlayerNumber(players[i]);
		}

		//Logging Initial Deal of Cards to players
		for (int i = 0; i < nPlayers; i++){
			logger.logInitialDeal(this, hands[i], i);
		}
	}

	Hand discardHand = new Hand(deck);
	private void discardToCrib() {
		crib = new Hand(deck);
		RowLayout layout = new RowLayout(cribLocation, cribWidth);
		layout.setRotationAngle(0);
		crib.setView(this, layout);
		// crib.setTargetArea(cribTarget);
		crib.draw();
		for (IPlayer player: players) {
			for (int i = 0; i < nDiscards; i++) {
				Card discardCard = player.discard();
				transfer(discardCard, crib);
				Card copyDiscardCard = discardCard.clone();
				discardHand.insert(copyDiscardCard, false);
			}
			logger.logDiscardCards(this, discardHand,player.id);
			discardHand.removeAll(false);
			crib.sort(Hand.SortType.POINTPRIORITY, true);

			for (int i = 0; i < player.hand.getNumberOfCards(); i++){
				Card copy = player.hand.get(i).clone();
				player.startingHand.insert(copy, false);
			}
		}
	}

	private void starter(Hand pack) {
		starter = new Hand(deck);  // if starter is a Jack, the dealer gets 2 points
		RowLayout layout = new RowLayout(starterLocation, 0);
		layout.setRotationAngle(0);
		starter.setView(this, layout);
		starter.draw();
		Card dealt = randomCard(pack);
		Card copyDealt = dealt.clone();
		dealt.setVerso(false);
		transfer(dealt, starter);
		logger.logStarterCard(this,copyDealt);
	}

	private void play() throws IllegalAccessException, ClassNotFoundException, InstantiationException {
		List<Hand> segments = new ArrayList<>();
		int currentPlayer = 0; // Player 1 is dealer
		Segment s = new Segment();
		s.reset(segments);
		while (!(players[0].emptyHand() && players[1].emptyHand())) {
			// System.out.println("segments.size() = " + segments.size());
			Card nextCard = players[currentPlayer].lay(THIRTYONE-total(s.segment));
			if (nextCard == null) {
				if (s.go) {
					// Another "go" after previous one with no intervening cards
					// lastPlayer gets 1 point for a "go"
					Score.scores[s.lastPlayer] += GO;
					logger.logPlayScore(players[s.lastPlayer], Score.scores[s.lastPlayer], GO, "go");
					s.newSegment = true;
				} else {
					// currentPlayer says "go"
					s.go = true;
				}
				currentPlayer = (currentPlayer+1) % 2;
			} else {
				s.lastPlayer = currentPlayer; // last Player to play a card in this segment
				Card copyNextCard = nextCard.clone();
				transfer(nextCard, s.segment);
				logger.logPlayCard(this,total(s.segment), copyNextCard, players[currentPlayer]);
				/*THIS IS WHERE SCORING GOES DURING THE PLAY*/
				Score.scores[s.lastPlayer] += Score.scoreDuringPlay(s.segment, players[currentPlayer]);
				if (total(s.segment) == THIRTYONE) {

					// lastPlayer gets 2 points for a 31
					Score.scores[s.lastPlayer] += THIRTYONE_TWO;
					logger.logPlayScore(players[currentPlayer], Score.scores[s.lastPlayer], THIRTYONE_TWO, "thirtyone");
					s.newSegment = true;
					currentPlayer = (currentPlayer+1) % 2;

				} else {

					//  lastPlayer gets 2 points for a 15
					if (total(s.segment) == FIFTEEN) {
						Score.scores[s.lastPlayer] += FIFTEEN_TWO;
						logger.logPlayScore(players[currentPlayer], Score.scores[s.lastPlayer], FIFTEEN_TWO, "fifteen");
					}
					// if it is "go" then same player gets another turn
					if (!s.go) {
						currentPlayer = (currentPlayer+1) % 2;
					}
				}
			}
			updateScores();
			if (s.newSegment) {
				segments.add(s.segment);
				s.reset(segments);
			}
		}
		if (total(s.segment) != THIRTYONE){
			Score.scores[s.lastPlayer] += GO;
			// System.out.println("Go. Score for Player: " + s.lastPlayer + " is: " + Score.scores[s.lastPlayer]);
			logger.logPlayScore(players[s.lastPlayer], Score.scores[s.lastPlayer], GO, "go");
		}
	}

	void showHandsCrib() throws IllegalAccessException, ClassNotFoundException, InstantiationException {
		// System.out.println("\n\nSHOW BEGINING\n\n");
		List<Hand> startingHands = new ArrayList<>();

		for (int j = 0; j < nPlayers; j++){
			Hand startingHand = new Hand(deck);
			for (int k = 0; k < players[j].startingHand.getNumberOfCards(); k++){
				startingHand.insert(players[j].startingHand.get(k).clone(), false);
			}
			startingHands.add(startingHand);
		}

		Hand startingHand = new Hand(deck);
		for (int k = 0; k < crib.getNumberOfCards(); k++){
			startingHand.insert(crib.get(k).clone(), false);
		}
		startingHands.add(startingHand);

		for (int i = 0; i < nPlayers; i++) {
			players[i].startingHand.insert(starter.getLast().clone(), false);

		}
		crib.insert(starter.getLast().clone(),false);

		// score player 0 (non dealer)
		// score player 1 (dealer)
		for (int i = 0; i < nPlayers; i++) {
			logger.logShowHand(this, players[i], starter.getLast(), startingHands.get(i));
			Score.scoreDuringShow(players[i].startingHand, players[i]);
		}

		// score crib (for dealer)
		logger.logShowHand(this, players[1], starter.getLast(), startingHands.get(2));
		Score.scoreDuringShow(crib, players[1]);
		updateScores();
	}

	public Cribbage() throws IllegalAccessException, InstantiationException, ClassNotFoundException {
		super(850, 700, 30);
		// setSimulationPeriod(1);
		cribbage = this;
		// Set the title in the window's title bar.
		setTitle("Cribbage (V" + version + ") Constructed for UofM SWEN30006 with JGameGrid (www.aplu.ch)");
		setStatusText("Initializing...");
		initScore();
		Hand pack = deck.toHand(false);
		RowLayout layout = new RowLayout(starterLocation, 0);
		layout.setRotationAngle(0);
		pack.setView(this, layout);
		pack.setVerso(true);
		pack.draw();
		// Add seed text actor.
		addActor(new TextActor("Seed: " + SEED, Color.BLACK, bgColor, normalFont), seedLocation);

		//Log the Seed Number
		logger.logSeedNumber(SEED);
		/* Play the round */
		deal(pack, hands);
		discardToCrib();
		starter(pack);
		play();
		showHandsCrib();

		// Add gameover actor.
		addActor(new Actor("sprites/gameover.gif"), textLocation);
		setStatusText("Game over.");
		refresh();
	}

	public static void main(String[] args)
			throws IOException, ClassNotFoundException, NoSuchMethodException, InvocationTargetException,
			InstantiationException, IllegalAccessException {

		/* Handle Properties */
		// System.out.println("Working Directory = " + System.getProperty("user.dir"));
		Properties cribbageProperties = new Properties();
		// Default properties
		cribbageProperties.setProperty("Animate", "true");
		// Set two players' types
		cribbageProperties.setProperty("Player0", "cribbage.RandomPlayer");
		cribbageProperties.setProperty("Player1", "cribbage.HumanPlayer");

		// Read properties
		try (FileReader inStream = new FileReader("cribbage.properties")) {
			cribbageProperties.load(inStream);
		}

		// Control Graphics
		ANIMATE = Boolean.parseBoolean(cribbageProperties.getProperty("Animate"));

		// Control Randomisation
		// Read the first argument and save it as a seed if it exists
		if (args.length > 0 ) {
			// Use arg seed - overrides property
			SEED = Integer.parseInt(args[0]);
		} else {
			// No argument then check the property file
			String seedProp = cribbageProperties.getProperty("Seed");
			if (seedProp != null) {
				// Use property seed if is exists
				SEED = Integer.parseInt(seedProp);
			} else {
				// and no property so randomise the seed itself
				SEED = new Random().nextInt();
			}
		}

		// Set up the randomisation using the seed
		random = new Random(SEED);

		// Control Player Types
		Class<?> clazz;
		// Create two Players in according to their type
		clazz = Class.forName(cribbageProperties.getProperty("Player0"));
		// Uses the constructor represented by this Constructor object to create and initialize a new instance of
		// the constructor's declaring class, with the specified initialization parameters.
		players[0] = (IPlayer) clazz.getConstructor().newInstance();
		clazz = Class.forName(cribbageProperties.getProperty("Player1"));
		players[1] = (IPlayer) clazz.getConstructor().newInstance();
		// End of properties setting

		// Start the Cribbage game
		new Cribbage();
	}

}
