package cribbage;

import ch.aplu.jcardgame.Hand;

public interface PlayStrategy {
    int calculateScore(Hand h);
}
