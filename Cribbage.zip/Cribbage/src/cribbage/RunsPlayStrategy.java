package cribbage;

import ch.aplu.jcardgame.Card;
import ch.aplu.jcardgame.Hand;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;

public class RunsPlayStrategy implements PlayStrategy {

    private final static int RUN_OF_THREE = 3;
    private final static int RUN_OF_FOUR = 4;
    private final static int RUN_OF_FIVE = 5;
    private final static int RUN_OF_SIX = 6;
    private final static int RUN_OF_SEVEN = 7;
    private final static int RUN_OF_THREE_MARK = 3;
    private final static int RUN_OF_FOUR_MARK = 4;
    private final static int RUN_OF_FIVE_MARK = 5;
    private final static int RUN_OF_SIX_MARK = 6;
    private final static int RUN_OF_SEVEN_MARK = 7;

    private final static Map<Integer, Integer> runMap = Map.of(
            RUN_OF_THREE,RUN_OF_THREE_MARK,
            RUN_OF_FOUR,RUN_OF_FOUR_MARK,
            RUN_OF_FIVE,RUN_OF_FIVE_MARK,
            RUN_OF_SIX,RUN_OF_SIX_MARK,
            RUN_OF_SEVEN,RUN_OF_SEVEN_MARK
    );

    public RunsPlayStrategy() {
    }

    @Override
    public int calculateScore(Hand h) {
        int score = 0;
        for (int i = RUN_OF_THREE; i <= RUN_OF_SEVEN; i ++) {
            int addingScore = runOfInt(h, i);
            if (addingScore == 0) {
                return score;
            } else {
                score += addingScore;
            }
        }
        return score;
    }

    // Default sorting method for Hand
    public void sort(Hand h) {
        h.sort(Hand.SortType.POINTPRIORITY, false);
    }

    // Calculates whether
    public int runOfInt(Hand h, int runNum) {
        int handLength = h.getNumberOfCards();
        if (handLength < runNum) {
            return 0;
        } else {
            Hand newHand = new Hand(Cribbage.deck);
            for (int i = handLength - runNum; i < handLength ; i++) {
                Card c = h.get(i);
                newHand.insert(new Card(Cribbage.deck, c.getSuit(), c.getRank()), false);
            }
            sort(newHand);
            return newHand.getSequences(runNum).size() * runMap.get(runNum);
        }
    }

}
