package cribbage;

//singleton factory
public class ScoringStrategyFactory {
    //responsibility of creating either the
    private static ScoringStrategyFactory scoringStrategyFactory = null;

    //private constructor restricted to this class itself
    private ScoringStrategyFactory() {

    }

    // static method to create instance of the ScoringStrategyFactory class
    public static ScoringStrategyFactory getInstance() {
        // lazy initialization
        if (scoringStrategyFactory == null) {
            scoringStrategyFactory = new ScoringStrategyFactory();
        }
        return scoringStrategyFactory;
    }

    public PlayStrategy getPlayStrategy(String playStrategyType) throws ClassNotFoundException, IllegalAccessException, InstantiationException {

        if (playStrategyType.equals("RunsPlayStrategy")) {
            return new RunsPlayStrategy();
        }

        if (playStrategyType.equals("PairsPlayStrategy")) {
            return new PairsPlayStrategy();
        }

        return null;
    }

    public ShowStrategy getShowStrategy(String showStrategyType) throws ClassNotFoundException, IllegalAccessException, InstantiationException {
        //ShowStrategy strategy = (ShowStrategy) Class.forName(showStrategyType).newInstance();

        if (showStrategyType.equals("TotalsShowStrategy")) {
            return new TotalsShowStrategy();
        }

        if (showStrategyType.equals("RunsShowStrategy")) {
            return new RunsShowStrategy();
        }

        if (showStrategyType.equals("PairsShowStrategy")) {
            return new PairsShowStrategy();
        }

        if (showStrategyType.equals("FlushShowStrategy")) {
            return new FlushShowStrategy();
        }

        if (showStrategyType.equals("JackShowStrategy")) {
            return new JackShowStrategy();
        }

        return null;
    }

}
