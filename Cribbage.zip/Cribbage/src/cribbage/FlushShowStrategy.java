package cribbage;

import ch.aplu.jcardgame.Card;
import ch.aplu.jcardgame.Hand;

import java.util.ArrayList;

public class FlushShowStrategy implements ShowStrategy {

    private final static int FLUSH_OF_FOUR = 4;
    private final static int FLUSH_OF_FIVE = 5;
    private final static int FLUSH_OF_FOUR_MARK = 4;
    private final static int FLUSH_OF_FIVE_MARK = 5;

    private ArrayList<Integer> scoreList;
    private ArrayList<Card[]> successCombinationList;

    public FlushShowStrategy() {
        scoreList = new ArrayList<>();
        successCombinationList = new ArrayList<>();
    }

    @Override
    public CombinationResult calculateScore(Hand h) {
        if (flushOfFour(h) && flushOfFive(h)) {
            scoreList.add(FLUSH_OF_FIVE_MARK);
            successCombinationList.add(copyHand(h, h.getNumberOfCards()));
        } else if (flushOfFour(h) && !flushOfFive(h)) {
            scoreList.add(FLUSH_OF_FOUR_MARK);
            successCombinationList.add(copyHand(h, h.getNumberOfCards() - 1));
        }

        return new CombinationResult(scoreList, successCombinationList);
    }

    public boolean flushOfFour(Hand h) {
        Hand newHand = new Hand(Cribbage.deck);
        for (int i = 0; i < h.getNumberOfCards() - 1; i++) {
            newHand.insert(h.get(i).clone(), false);
        }
        // Get the Suit of the first card of the hand
        Cribbage.Suit suit = (Cribbage.Suit) newHand.getFirst().getSuit();
        // If all of the cards are of the same Suit as the first one
        if (newHand.getCardsWithSuit(suit).size() == FLUSH_OF_FOUR) {
            return true;
        } else {
            return false;
        }
    }

    public boolean flushOfFive(Hand h) {
        Cribbage.Suit suit = (Cribbage.Suit)h.getLast().getSuit();
        if (h.getCardsWithSuit(suit).size() == FLUSH_OF_FIVE) {
            Card[] flush = new Card[h.getNumberOfCards()];
            for (int i = 0; i < h.getNumberOfCards(); i++) {
                flush[i] = h.get(i).clone();
            }
            successCombinationList.add(flush.clone());
            scoreList.add(FLUSH_OF_FIVE_MARK);
            return true;
        } else {
            return false;
        }
    }

    // Copy a hand to a card array with given number of cards to copy (from the first).
    public Card[] copyHand(Hand h, int copyLength) {
        Card[] cards = new Card[copyLength];
        for (int i = 0; i < copyLength; i++) {
            cards[i] = h.get(i).clone();
        }
        return cards;
    }
}
