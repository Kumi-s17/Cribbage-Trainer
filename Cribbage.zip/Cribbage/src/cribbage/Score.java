package cribbage;

import ch.aplu.jcardgame.Card;
import ch.aplu.jcardgame.Hand;

public class Score {
    // Scores

    int[] scores;
    private int nPlayers;
    private Logger logger;
    ScoringStrategyFactory factory = ScoringStrategyFactory.getInstance();
    Cribbage cribbage;

    public Score (int nplayers, Logger logger,Cribbage cribbage) {
        this.nPlayers = nplayers;
        scores = new int[this.nPlayers];
        this.logger = logger;
        this.cribbage = cribbage;
    }

    public int scoreDuringPlay(Hand hand, IPlayer player) throws IllegalAccessException, InstantiationException, ClassNotFoundException {
        int score = 0;

        int scoreRuns = factory.getPlayStrategy("RunsPlayStrategy").calculateScore(hand);
        score += scoreRuns;
        if (scoreRuns != 0) {
            logger.logPlayScore(player, scores[player.id] + score, scoreRuns, "runs");
        }

        int scorePairs = factory.getPlayStrategy("PairsPlayStrategy").calculateScore(hand);
        score += scorePairs;
        if (scorePairs != 0) {
            logger.logPlayScore(player, scores[player.id] + score, scorePairs, "pair");
        }

        return score;
    }

    public void scoreDuringShow(Hand hand, IPlayer player) throws IllegalAccessException, InstantiationException, ClassNotFoundException {

        CombinationResult combinationResult;

        combinationResult = factory.getShowStrategy("TotalsShowStrategy").calculateScore(hand);
        for (int i = 0; i < combinationResult.getScoreList().size(); i++) {
            Card[] combination = combinationResult.getSuccessCombinationList().get(i);
            int scoreAchieved = combinationResult.getScoreList().get(i);
            scores[player.id] += scoreAchieved;
            Hand combinationHand = new Hand(cribbage.deck);
            for (int j = 0; j< combination.length; j++) {
                combinationHand.insert(combination[j], false);
            }
            logger.logShowScore(cribbage, player, scores[player.id], scoreAchieved, "fifteen", combinationHand);
        }

        combinationResult = factory.getShowStrategy("RunsShowStrategy").calculateScore(hand);
        for (int i = 0; i < combinationResult.getScoreList().size(); i++) {
            Card[] combination = combinationResult.getSuccessCombinationList().get(i);
            int scoreAchieved = combinationResult.getScoreList().get(i);
            scores[player.id] += scoreAchieved;
            Hand combinationHand = new Hand(cribbage.deck);
            for (int j = 0; j< combination.length; j++) {
                combinationHand.insert(combination[j], false);
            }
            logger.logShowScore(cribbage, player, scores[player.id], scoreAchieved, "run" + combination.length, combinationHand);
        }

        combinationResult = factory.getShowStrategy("PairsShowStrategy").calculateScore(hand);
        for (int i = 0; i < combinationResult.getScoreList().size(); i++) {
            Card[] combination = combinationResult.getSuccessCombinationList().get(i);
            int scoreAchieved = combinationResult.getScoreList().get(i);
            scores[player.id] += scoreAchieved;
            Hand combinationHand = new Hand(cribbage.deck);
            for (int j = 0; j< combination.length; j++) {
                combinationHand.insert(combination[j], false);
            }
            logger.logShowScore(cribbage, player, scores[player.id], scoreAchieved, "pair" + combination.length, combinationHand);
        }

        combinationResult = factory.getShowStrategy("FlushShowStrategy").calculateScore(hand);
        for (int i = 0; i < combinationResult.getScoreList().size(); i++) {
            Card[] combination = combinationResult.getSuccessCombinationList().get(i);
            int scoreAchieved = combinationResult.getScoreList().get(i);
            scores[player.id] += scoreAchieved;
            Hand combinationHand = new Hand(cribbage.deck);
            for (int j = 0; j< combination.length; j++) {
                combinationHand.insert(combination[j], false);
            }
            logger.logShowScore(cribbage, player, scores[player.id], scoreAchieved, "flush" + combination.length, combinationHand);
        }


        combinationResult = factory.getShowStrategy("JackShowStrategy").calculateScore(hand);
        for (int i = 0; i < combinationResult.getScoreList().size(); i++) {
            Card[] combination = combinationResult.getSuccessCombinationList().get(i);
            int scoreAchieved = combinationResult.getScoreList().get(i);
            scores[player.id] += scoreAchieved;
            Hand combinationHand = new Hand(cribbage.deck);
            for (int j = 0; j< combination.length; j++) {
                combinationHand.insert(combination[j], false);
            }
            logger.logShowScore(cribbage, player, scores[player.id], scoreAchieved, "jack", combinationHand);
        }

    }

}
