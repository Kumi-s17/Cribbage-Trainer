package cribbage;

import ch.aplu.jcardgame.Card;
import ch.aplu.jcardgame.Hand;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class PairsShowStrategy implements ShowStrategy {

    private final static int PAIR = 2;
    private final static int TRIP = 6;
    private final static int QUAD = 12;
    private final static int PAIR_MARK = 2;
    private final static  int TRIP_MARK = 6;
    private final static int QUAD_MARK = 12;
    private final static Map<Integer, Integer> pairMap = Map.of(
            PAIR,PAIR_MARK,
            TRIP,TRIP_MARK,
            QUAD,QUAD_MARK
    );

    private ArrayList<Integer> scoreList;
    private ArrayList<Card[]> successCombinationList;

    public PairsShowStrategy() {
        scoreList = new ArrayList<>();
        successCombinationList = new ArrayList<>();
    }

    @Override
    public CombinationResult calculateScore(Hand h) {
        int handLength = h.getNumberOfCards();
        if (handLength >= 2) {
            ArrayList<Card> cards = h.getCardList();
            ArrayList<Card[]> combinationArrayList = new ArrayList<>();
            for (int i = 1; i <= handLength; i++) {
                generateCombinations(cards, handLength, i, combinationArrayList);
            }
            for (Card[] combination : combinationArrayList) {
                if (checkPairs(combination)) {
                    scoreList.add(pairMap.get(combination.length));
                    successCombinationList.add(combination.clone());
                }
            }
        }
        return new CombinationResult(scoreList, successCombinationList);
    }

    public boolean checkPairs(Card[] cards) {
        int cardNum = cards.length;
        if (cardNum < PAIR) {
            return false;
        }
        for (int i = 0; i < cardNum - 1; i++) {
            if (((Cribbage.Rank)cards[i].getRank()).order != ((Cribbage.Rank)cards[i+1].getRank()).order) {
                return false;
            }
        }
        return true;
    }
}
