package cribbage;

import ch.aplu.jcardgame.Card;
import ch.aplu.jcardgame.Hand;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class RunsShowStrategy implements ShowStrategy {

    private final static int RUN_OF_THREE = 3;
    private final static int RUN_OF_FOUR = 4;
    private final static int RUN_OF_FIVE = 5;
    private final static int RUN_OF_THREE_MARK = 3;
    private final static int RUN_OF_FOUR_MARK = 4;
    private final static int RUN_OF_FIVE_MARK = 5;
    private final static Map<Integer, Integer> runMap = Map.of(
            RUN_OF_THREE,RUN_OF_THREE_MARK,
            RUN_OF_FOUR,RUN_OF_FOUR_MARK,
            RUN_OF_FIVE,RUN_OF_FIVE_MARK
    );

    private ArrayList<Integer> scoreList;
    private ArrayList<Card[]> successCombinationList;

    public RunsShowStrategy() {
        scoreList = new ArrayList<>();
        successCombinationList = new ArrayList<>();
    }

    @Override
    public CombinationResult calculateScore(Hand h) {
        int handLength = h.getNumberOfCards();
        // Minimal number of cards required to form a run is three.
        if (handLength >= RUN_OF_THREE) {
            ArrayList<Card> cards = h.getCardList();
            ArrayList<Card[]> combinationArrayList = new ArrayList<>();
            for (int i = 1; i <= handLength; i++) {
                generateCombinations(cards, handLength, i, combinationArrayList);
            }
            for (Card[] combination : combinationArrayList) {
                if (checkRuns(combination)) {
                    scoreList.add(runMap.get(combination.length));
                    successCombinationList.add(combination.clone());
                }
            }
        }
        return new CombinationResult(scoreList, successCombinationList);
    }

    public boolean checkRuns(Card[] cards) {
        int cardNum = cards.length;
        if (cardNum < RUN_OF_THREE) {
            return false;
        }
        for (int i = 0; i < cardNum - 1; i++) {
            if (Math.abs(((Cribbage.Rank)cards[i+1].getRank()).order - ((Cribbage.Rank)cards[i].getRank()).order) != 1) {
                return false;
            }
        }
        return true;
    }

}